/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */

$(document).ready(function () {

    $("#form-login").submit(function (event) {
      
        event.preventDefault();
        autenticarUsuario();
    });
    $("#form-register").submit(function (event) {

        event.preventDefault();
        registrarUsuario();
    });
});

//esto trabaja con el login.html de aqui trae usuario y contraseña del front y back del username
function autenticarUsuario() {

    let username = $("#usuario").val();
    let contrasena = $("#contrasena").val();
    $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletUsuarioLogin",
        data: $.param({
            username: username,
            contrasena: contrasena
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);
            if (parsedResult != false) {
                $("#login-error").addClass("d-none");
                let username = parsedResult['username'];
                document.location.href = "home.html?username=" + username;
            } else {
                $("#login-error").removeClass("d-none");
            }
        }
    });
}
function registrarUsuario() {
  
    let idenUsuario = $("#input-idenUsuario").val();
    let username = $("#input-username").val();
    let contrasena = $("#input-contrasena").val();
    let contrasenaConfirmacion = $("#input-contrasena-repeat").val();
    let nomUsuario = $("#input-nomUsuario").val();
    let apeUsuario = $("#input-apeUsuario").val();
    let telUsuario = $("#input-telUsuario").val();
    let emailUsuario = $("#input-emailUsuario").val();
    let perfilUsuario = $("#input-perfilUsuario").val();
    if (contrasena == contrasenaConfirmacion) {

        $.ajax({
            type: "GET",
            dataType: "html",
            url: "./ServletUsuarioRegister",
            data: $.param({
                idenUsuario: idenUsuario,
                username: username,
                contrasena: contrasena,
                contrasenaConfirmacion: contrasenaConfirmacion,
                nomUsuario: nomUsuario,
                apeUsuario: apeUsuario,
                telUsuario: telUsuario,
                emailUsuario: emailUsuario,
                perfilUsuario: perfilUsuario

            }),
            success: function (result) {
                let parsedResult = JSON.parse(result);
                if (parsedResult != false) {
                    $("#register-error").addClass("d-none");
                    let username = parsedResult['username'];
                    document.location.href = "home.html?username=" + username;
                } else {
                    $("#register-error").removeClass("d-none");
                    $("#register-error").html("Error en el registro del usuario");
                }
            }
        });
    } else {
        $("#register-error").removeClass("d-none");
        $("#register-error").html("Las contraseñas no coinciden");
    }
}

