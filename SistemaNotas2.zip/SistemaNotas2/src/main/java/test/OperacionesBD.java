
package test;

import beans.Usuario;
import connection.BDConnection;
import java.sql.ResultSet;
import java.sql.Statement;

public class OperacionesBD {
    public static void main(String[] args) {
        listarUsuario();
        
    }
    
    public static void actualizarUsuarios(int id_usuario,String idenUsuario,String username,String contrasena,String nomUsuario,String apeUsuario,String telUsuario,String emailUsuario,String perfilUsuario){
        BDConnection con = new BDConnection();
        String sql="UPDATE usuario SET idenUsuario = '" + idenUsuario + "' WHERE id_usuario =" + id_usuario;
        try {
            Statement st= con.getConnection().createStatement();
            st.executeUpdate(sql);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }finally {
            con.desconectar();
        }
    }
    public static void listarUsuario(){
        BDConnection con = new BDConnection();
        String sql="SELECT * from usuario";
        try {
            Statement st= con.getConnection().createStatement();
           ResultSet rs =st.executeQuery(sql);
           while(rs.next()){
               int id_usuario=rs.getInt("id_usuario");
               String idenUsuario = rs.getString("idenUsuario");
               String username = rs.getString("username");
               String contrasena = rs.getString("contrasena");
               String nomUsuario = rs.getString("nomUsuario");
               String apeUsuario = rs.getString("apeUsuario");
               String telUsuario = rs.getString("telUsuario");
               String emailUsuario = rs.getString("emailUsuario");             
               String perfilUsuario = rs.getString("perfilUsuario");
               
               Usuario usuario= new Usuario(id_usuario,idenUsuario,username,contrasena,nomUsuario,apeUsuario,telUsuario,emailUsuario, perfilUsuario);

             System.out.println(usuario.toString());
               
               
           }
           st.executeQuery(sql);
           
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }finally {
            con.desconectar();
        }
        
    }
    
}
