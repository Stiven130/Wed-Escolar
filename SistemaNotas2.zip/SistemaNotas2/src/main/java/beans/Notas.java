/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author PAOLA
 */
public class Notas {
    private int id_notas;
    private int id_grado;
    private int id_materia;
    private int id_docente;
    private int id_estudiante;
    private double nota;
    private String observacion;

    public Notas(int id_notas, int id_grado, int id_materia, int id_docente, int id_estudiante, double nota, String observacion) {
        this.id_notas = id_notas;
        this.id_grado = id_grado;
        this.id_materia = id_materia;
        this.id_docente = id_docente;
        this.id_estudiante = id_estudiante;
        this.nota = nota;
        this.observacion = observacion;
    }

    public int getIdNotas() {
        return id_notas;
    }

    public void setIdNotas(int idNotas) {
        this.id_notas = idNotas;
    }

    public int getId_Grado() {
        return id_grado;
    }

    public void setId_Grado(int id_grado) {
        this.id_grado = id_grado;
    }

    public int getId_Materia() {
        return id_materia;
    }

    public void setId_Materia(int id_materia) {
        this.id_materia = id_materia;
    }

    public int getId_docente() {
        return id_docente;
    }

    public void setId_docente(int id_docente) {
        this.id_docente = id_docente;
    }

    public int getId_estudiante() {
        return id_estudiante;
    }

    public void setId_estudiante(int id_estudiante) {
        this.id_estudiante = id_estudiante;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    @Override
    public String toString() {
        return "Notas{" + "idNotas=" + id_notas + ", id_Grado=" + id_grado + ", id_Materia=" + id_materia + ", id_docente=" + id_docente + ", id_estudiante=" + id_estudiante + ", nota=" + nota + ", observacion=" + observacion + '}';
    }
    
    
    
}
