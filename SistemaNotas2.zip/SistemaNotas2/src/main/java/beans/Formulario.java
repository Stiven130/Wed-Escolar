/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author PAOLA
 */
public class Formulario {
    private int id_formulario;
    private String nomFormulario;
    private String categoFormulario;
    private String descFormulario;
    private String docuFormulario;
    private String formatFormulario;

    public Formulario(int id_formulario, String nomFormulario, String categoFormulario, String descFormulario, String docuFormulario, String formatFormulario) {
        this.id_formulario = id_formulario;
        this.nomFormulario = nomFormulario;
        this.categoFormulario = categoFormulario;
        this.descFormulario = descFormulario;
        this.docuFormulario = docuFormulario;
        this.formatFormulario = formatFormulario;
    }

    public int getIdFormulario() {
        return id_formulario;
    }

    public void setIdFormulario(int idFormulario) {
        this.id_formulario = idFormulario;
    }

    public String getNomFormulario() {
        return nomFormulario;
    }

    public void setNomFormulario(String nomFormulario) {
        this.nomFormulario = nomFormulario;
    }

    public String getCategoFormulario() {
        return categoFormulario;
    }

    public void setCategoFormulario(String categoFormulario) {
        this.categoFormulario = categoFormulario;
    }

    public String getDescFormulario() {
        return descFormulario;
    }

    public void setDescFormulario(String descFormulario) {
        this.descFormulario = descFormulario;
    }

    public String getDocuFormulario() {
        return docuFormulario;
    }

    public void setDocuFormulario(String docuFormulario) {
        this.docuFormulario = docuFormulario;
    }

    public String getFormatFormulario() {
        return formatFormulario;
    }

    public void setFormatFormulario(String formatFormulario) {
        this.formatFormulario = formatFormulario;
    }

    @Override
    public String toString() {
        return "Formulario{" + "idFormulario=" + id_formulario + ", nomFormulario=" + nomFormulario + ", categoFormulario=" + categoFormulario + ", descFormulario=" + descFormulario + ", docuFormulario=" + docuFormulario + ", formatFormulario=" + formatFormulario + '}';
    }
    
    
}
