/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

import java.sql.Time;

/**
 *
 * @author PAOLA
 */
public class Hora {
    private int id_hora;
    private Time hora_inicio;
    private Time hora_fin;

    public Hora(int id_hora, Time hora_inicio, Time hora_fin) {
        this.id_hora = id_hora;
        this.hora_inicio = hora_inicio;
        this.hora_fin = hora_fin;
    }

    public int getIdHora() {
        return id_hora;
    }

    public void setIdHora(int idHora) {
        this.id_hora = idHora;
    }

    public Time getHora_inicio() {
        return hora_inicio;
    }

    public void setHora_inicio(Time hora_inicio) {
        this.hora_inicio = hora_inicio;
    }

    public Time getHora_fin() {
        return hora_fin;
    }

    public void setHora_fin(Time hora_fin) {
        this.hora_fin = hora_fin;
    }

    @Override
    public String toString() {
        return "Hora{" + "idHora=" + id_hora + ", hora_inicio=" + hora_inicio + ", hora_fin=" + hora_fin + '}';
    }
    
    
}
