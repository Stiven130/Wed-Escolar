/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author PAOLA
 */
public class Jornada {
    private int id_jornada;
    private String nomJornada;

    public Jornada(int id_jornada, String nomJornada) {
        this.id_jornada = id_jornada;
        this.nomJornada = nomJornada;
    }

    public int getIdJornada() {
        return id_jornada;
    }

    public void setIdJornada(int idJornada) {
        this.id_jornada = idJornada;
    }

    public String getNomJornada() {
        return nomJornada;
    }

    public void setNomJornada(String nomJornada) {
        this.nomJornada = nomJornada;
    }

    @Override
    public String toString() {
        return "Jornada{" + "idJornada=" + id_jornada + ", nomJornada=" + nomJornada + '}';
    }
    
    
    
}
