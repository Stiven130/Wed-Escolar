/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

import java.awt.Image;

/**
 *
 * @author PAOLA
 */
public class Colegio {
    private int idColegio;
    private String nomColegio;
    private String rector;
    private String dirColegio;
    private String modalidad;
    

    public Colegio(int idColegio, String nomColegio, String rector, String dirColegio, String modalidad) {
        this.idColegio = idColegio;
        this.nomColegio = nomColegio;
        this.rector = rector;
        this.dirColegio = dirColegio;
        this.modalidad = modalidad;
      
    }

    public int getIdColegio() {
        return idColegio;
    }

    public void setIdColegio(int idColegio) {
        this.idColegio = idColegio;
    }

    public String getNomColegio() {
        return nomColegio;
    }

    public void setNomColegio(String nomColegio) {
        this.nomColegio = nomColegio;
    }

    public String getRector() {
        return rector;
    }

    public void setRector(String rector) {
        this.rector = rector;
    }

    public String getDirColegio() {
        return dirColegio;
    }

    public void setDirColegio(String dirColegio) {
        this.dirColegio = dirColegio;
    }

    public String getModalidad() {
        return modalidad;
    }

    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }

 

    @Override
    public String toString() {
        return "Colegio{" + "idColegio=" + idColegio + ", nomColegio=" + nomColegio + ", rector=" + rector + ", dirColegio=" + dirColegio + ", modalidad=" + modalidad + '}';
    }


    
    
}
