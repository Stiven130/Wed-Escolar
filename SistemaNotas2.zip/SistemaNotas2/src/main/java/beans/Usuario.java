
package beans;



public class Usuario {
    
    
    private int id_usuario;
    private String idenUsuario;
    private String username;
    private String contrasena;
    private String nomUsuario;
    private String apeUsuario;
    private String telUsuario;
    private String emailUsuario;
    private String perfilUsuario;

    public Usuario(int id_usuario, String idenUsuario, String username, String contrasena, String nomUsuario, String apeUsuario, String telUsuario, String emailUsuario, String perfilUsuario) {
        this.id_usuario = id_usuario;
        this.idenUsuario = idenUsuario;
        this.username = username;
        this.contrasena = contrasena;
        this.nomUsuario = nomUsuario;
        this.apeUsuario = apeUsuario;
        this.telUsuario = telUsuario;
        this.emailUsuario = emailUsuario;
        this.perfilUsuario = perfilUsuario;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getIdenUsuario() {
        return idenUsuario;
    }

    public void setIdenUsuario(String idenUsuario) {
        this.idenUsuario = idenUsuario;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getNomUsuario() {
        return nomUsuario;
    }

    public void setNomUsuario(String nomUsuario) {
        this.nomUsuario = nomUsuario;
    }

    public String getApeUsuario() {
        return apeUsuario;
    }

    public void setApeUsuario(String apeUsuario) {
        this.apeUsuario = apeUsuario;
    }

    public String getTelUsuario() {
        return telUsuario;
    }

    public void setTelUsuario(String telUsuario) {
        this.telUsuario = telUsuario;
    }

    public String getEmailUsuario() {
        return emailUsuario;
    }

    public void setEmailUsuario(String emailUsuario) {
        this.emailUsuario = emailUsuario;
    }

    public String getPerfilUsuario() {
        return perfilUsuario;
    }

    public void setPerfilUsuario(String perfilUsuario) {
        this.perfilUsuario = perfilUsuario;
    }

    @Override
    public String toString() {
        return "Usuario{" + "id_usuario=" + id_usuario + ", idenUsuario=" + idenUsuario + ", username=" + username + ", contrasena=" + contrasena + ", nomUsuario=" + nomUsuario + ", apeUsuario=" + apeUsuario + ", telUsuario=" + telUsuario + ", emailUsuario=" + emailUsuario + ", perfilUsuario=" + perfilUsuario + '}';
    }

  

}