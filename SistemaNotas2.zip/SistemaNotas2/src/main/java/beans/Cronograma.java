/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

import java.awt.Image;
import java.sql.Time;
import java.util.Date;

/**
 *
 * @author PAOLA
 */
public class Cronograma {
    private int id_cronograma;
    private Date fechaCronograma;
    private Time horaCronograma;
    private String tipoCronograma;
    private String nomCronograma;
    private String desCronograma;
    private String responsable;
    private Image fotoCronograma;

    public Cronograma(int id_cronograma, Date fechaCronograma, Time horaCronograma, String tipoCronograma, String nomCronograma, String desCronograma, String responsable, Image fotoCronograma) {
        this.id_cronograma = id_cronograma;
        this.fechaCronograma = fechaCronograma;
        this.horaCronograma = horaCronograma;
        this.tipoCronograma = tipoCronograma;
        this.nomCronograma = nomCronograma;
        this.desCronograma = desCronograma;
        this.responsable = responsable;
        this.fotoCronograma = fotoCronograma;
    }

    public int getIdCronograma() {
        return id_cronograma;
    }

    public void setIdCronograma(int idCronograma) {
        this.id_cronograma = idCronograma;
    }

    public Date getFechaCronograma() {
        return fechaCronograma;
    }

    public void setFechaCronograma(Date fechaCronograma) {
        this.fechaCronograma = fechaCronograma;
    }

    public Time getHoraCronograma() {
        return horaCronograma;
    }

    public void setHoraCronograma(Time horaCronograma) {
        this.horaCronograma = horaCronograma;
    }

    public String getTipoCronograma() {
        return tipoCronograma;
    }

    public void setTipoCronograma(String tipoCronograma) {
        this.tipoCronograma = tipoCronograma;
    }

    public String getNomCronograma() {
        return nomCronograma;
    }

    public void setNomCronograma(String nomCronograma) {
        this.nomCronograma = nomCronograma;
    }

    public String getDesCronograma() {
        return desCronograma;
    }

    public void setDesCronograma(String desCronograma) {
        this.desCronograma = desCronograma;
    }

    public String getResponsable() {
        return responsable;
    }

    public void setResponsable(String responsable) {
        this.responsable = responsable;
    }

    public Image getFotoCronograma() {
        return fotoCronograma;
    }

    public void setFotoCronograma(Image fotoCronograma) {
        this.fotoCronograma = fotoCronograma;
    }

    @Override
    public String toString() {
        return "Cronograma{" + "idCronograma=" + id_cronograma + ", fechaCronograma=" + fechaCronograma + ", horaCronograma=" + horaCronograma + ", tipoCronograma=" + tipoCronograma + ", nomCronograma=" + nomCronograma + ", desCronograma=" + desCronograma + ", responsable=" + responsable + ", fotoCronograma=" + fotoCronograma + '}';
    }

   
    
    
}
