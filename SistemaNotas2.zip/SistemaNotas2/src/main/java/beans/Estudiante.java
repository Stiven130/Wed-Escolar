/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author PAOLA
 */
public class Estudiante {
    private int id_estudiante;
    private int id_usuario;
    private int telefono_acudiente;
    private int id_grado;

    public Estudiante(int id_estudiante, int id_usuario, int telefono_acudiente, int id_grado) {
        this.id_estudiante = id_estudiante;
        this.id_usuario = id_usuario;
        this.telefono_acudiente = telefono_acudiente;
        this.id_grado = id_grado;
    }

    public int getId_estudiante() {
        return id_estudiante;
    }

    public void setId_estudiante(int id_estudiante) {
        this.id_estudiante = id_estudiante;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getTelefono_acudiente() {
        return telefono_acudiente;
    }

    public void setTelefono_acudiente(int telefono_acudiente) {
        this.telefono_acudiente = telefono_acudiente;
    }

    public int getId_grado() {
        return id_grado;
    }

    public void setId_grado(int id_grado) {
        this.id_grado = id_grado;
    }

    @Override
    public String toString() {
        return "Estudiante{" + "id_estudiante=" + id_estudiante + ", id_usuario=" + id_usuario + ", telefono_acudiente=" + telefono_acudiente + ", id_grado=" + id_grado + '}';
    }
    
}
