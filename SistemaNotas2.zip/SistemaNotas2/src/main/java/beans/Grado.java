/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author PAOLA
 */
public class Grado {
    private int id_grado;
    private String nomGrado;

    public Grado(int id_grado, String nomGrado) {
        this.id_grado = id_grado;
        this.nomGrado = nomGrado;
    }

    public int getIdGrado() {
        return id_grado;
    }

    public void setIdGrado(int idGrado) {
        this.id_grado = idGrado;
    }

    public String getNomGrado() {
        return nomGrado;
    }

    public void setNomGrado(String nomGrado) {
        this.nomGrado = nomGrado;
    }

    @Override
    public String toString() {
        return "Grado{" + "idGrado=" + id_grado + ", nomGrado=" + nomGrado + '}';
    }
    
    
    
}
