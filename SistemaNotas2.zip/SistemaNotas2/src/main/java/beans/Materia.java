/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author PAOLA
 */
public class Materia {
    private int id_materia;
    private String nomMateria;

    public Materia(int id_materia, String nomMateria) {
        this.id_materia = id_materia;
        this.nomMateria = nomMateria;
    }

    public int getIdMateria() {
        return id_materia;
    }

    public void setIdMateria(int idMateria) {
        this.id_materia = idMateria;
    }

    public String getNomMateria() {
        return nomMateria;
    }

    public void setNomMateria(String nomMateria) {
        this.nomMateria = nomMateria;
    }

    @Override
    public String toString() {
        return "Materia{" + "idMateria=" + id_materia + ", nomMateria=" + nomMateria + '}';
    }
    
    
    
}
