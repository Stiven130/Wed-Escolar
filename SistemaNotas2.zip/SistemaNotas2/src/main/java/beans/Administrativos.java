/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author PAOLA
 */
public class Administrativos {
    private int id_ddministrativos;
    private int id_usuario;

    public Administrativos(int id_ddministrativos, int id_usuario) {
        this.id_ddministrativos = id_ddministrativos;
        this.id_usuario = id_usuario;
    }

    public int getId_ddministrativos() {
        return id_ddministrativos;
    }

    public void setId_ddministrativos(int id_ddministrativos) {
        this.id_ddministrativos = id_ddministrativos;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    @Override
    public String toString() {
        return "Administrativos{" + "id_ddministrativos=" + id_ddministrativos + ", id_usuario=" + id_usuario + '}';
    }
    

}