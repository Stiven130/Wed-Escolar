/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author PAOLA
 */
public class Docente {
     private int id_docente;
    private int id_usuario;
    private String gradoDocente;
    private int id_materia;

    public Docente(int id_docente, int id_usuario, String gradoDocente, int id_materia) {
        this.id_docente = id_docente;
        this.id_usuario = id_usuario;
        this.gradoDocente = gradoDocente;
        this.id_materia = id_materia;
    }

    public int getId_docente() {
        return id_docente;
    }

    public void setId_docente(int id_docente) {
        this.id_docente = id_docente;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getGradoDocente() {
        return gradoDocente;
    }

    public void setGradoDocente(String gradoDocente) {
        this.gradoDocente = gradoDocente;
    }

    public int getId_materia() {
        return id_materia;
    }

    public void setId_materia(int id_materia) {
        this.id_materia = id_materia;
    }

    @Override
    public String toString() {
        return "Docente{" + "id_docente=" + id_docente + ", id_usuario=" + id_usuario + ", gradoDocente=" + gradoDocente + ", id_materia=" + id_materia + '}';
    }

    
}
