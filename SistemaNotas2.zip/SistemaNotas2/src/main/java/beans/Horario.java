/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author PAOLA
 */
public class Horario {
    private int id_horario;
    private int id_docente;
    private int id_grado;
    private int id_materia;
    private int id_jornada;
    private int id_hora;

    public Horario(int id_horario, int id_docente, int id_grado, int id_materia, int id_jornada, int id_hora) {
        this.id_horario = id_horario;
        this.id_docente = id_docente;
        this.id_grado = id_grado;
        this.id_materia = id_materia;
        this.id_jornada = id_jornada;
        this.id_hora = id_hora;
    }

    public int getId_horario() {
        return id_horario;
    }

    public void setId_horario(int id_horario) {
        this.id_horario = id_horario;
    }

    public int getId_docente() {
        return id_docente;
    }

    public void setId_docente(int id_docente) {
        this.id_docente = id_docente;
    }

    public int getId_grado() {
        return id_grado;
    }

    public void setId_grado(int id_grado) {
        this.id_grado = id_grado;
    }

    public int getId_materia() {
        return id_materia;
    }

    public void setId_materia(int id_materia) {
        this.id_materia = id_materia;
    }

    public int getId_jornada() {
        return id_jornada;
    }

    public void setId_jornada(int id_jornada) {
        this.id_jornada = id_jornada;
    }

    public int getId_hora() {
        return id_hora;
    }

    public void setId_hora(int id_hora) {
        this.id_hora = id_hora;
    }

    @Override
    public String toString() {
        return "Horario{" + "id_horario=" + id_horario + ", id_docente=" + id_docente + ", id_grado=" + id_grado + ", id_materia=" + id_materia + ", id_jornada=" + id_jornada + ", id_hora=" + id_hora + '}';
    }
    
    
}
