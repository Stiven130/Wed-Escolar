/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author PAOLA
 */
public class Matricula {
    private int id_matricula;
    private int id_estudiante;
    private int id_grado;

    public Matricula(int id_matricula, int id_estudiante, int id_grado) {
        this.id_matricula = id_matricula;
        this.id_estudiante = id_estudiante;
        this.id_grado = id_grado;
    }

    public int getIdMatricula() {
        return id_matricula;
    }

    public void setIdMatricula(int idMatricula) {
        this.id_matricula = idMatricula;
    }

    public int getId_estudiante() {
        return id_estudiante;
    }

    public void setId_estudiante(int id_estudiante) {
        this.id_estudiante = id_estudiante;
    }

    public int getId_grado() {
        return id_grado;
    }

    public void setId_grado(int id_grado) {
        this.id_grado = id_grado;
    }

    @Override
    public String toString() {
        return "Matricula{" + "idMatricula=" + id_matricula + ", id_estudiante=" + id_estudiante + ", id_grado=" + id_grado + '}';
    }
    
    
    
}
