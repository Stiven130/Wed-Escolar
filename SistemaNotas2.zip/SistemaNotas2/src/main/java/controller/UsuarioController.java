package controller;

import java.sql.ResultSet;
import java.sql.Statement;
import com.google.gson.Gson;
import beans.Usuario;
import connection.BDConnection;


public class UsuarioController implements IUsuarioController {

    @Override
    public String login(String username, String contrasena) {

        Gson gson = new Gson();
        BDConnection con = new BDConnection();

 
        
        
     String sql = "SELECT * FROM usuario WHERE username = '"+ username 
             + "' and contrasena= '"+contrasena+"'";

        try {
            Statement st = con.getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {

                int id_usuario = rs.getInt("id_usuario");
                String idenUsuario = rs.getString("idenUsuario");
                String nomUsuario = rs.getString("nomUsuario");
                String apeUsuario = rs.getString("apeUsuario");
                String telUsuario = rs.getString("telUsuario");
                String emailUsuario = rs.getString("emailUsuario");
                String perfilUsuario = rs.getString("perfilUsuario");
                Usuario usuario = new Usuario(id_usuario, idenUsuario,username, contrasena, nomUsuario, 
                        apeUsuario, telUsuario, emailUsuario, perfilUsuario);

                return gson.toJson(usuario);
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }
        return "false";

    }
    

}
